# TransactionRadar - Quick Start Guide ⚡

## 🚀 البدء في 5 دقائق

### 1️⃣ التثبيت

```bash
# Clone the repository
git clone https://github.com/transactionradar/transactionradar.git
cd transactionradar

# Install dependencies
npm install

# Start development server
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) في المتصفح.

### 2️⃣ متغيرات البيئة

```bash
# Copy the example file
cp .env.example .env.local

# Edit with your settings
nano .env.local
```

**المتغيرات الأساسية:**
```
NEXT_PUBLIC_MEMPOOL_API=https://mempool.space/api
NEXT_PUBLIC_COINGECKO_API=https://api.coingecko.com/api/v3
```

### 3️⃣ البناء والاختبار

```bash
# Type checking
npm run type-check

# Build for production
npm run build

# Start production server
npm run start
```

## 📁 هيكل المشروع الأساسي

```
app/
├── components/          # React components
├── lib/                # Utilities and API calls
├── store/              # Zustand stores
├── types/              # TypeScript types
├── page.tsx            # Home page
├── layout.tsx          # Root layout
└── globals.css         # Global styles
```

## 🎨 التخصيص

### تغيير الألوان

Edit `tailwind.config.ts`:

```typescript
colors: {
  bitcoin: {
    500: '#your-color', // تغيير اللون الأساسي
  }
}
```

### إضافة صفحة جديدة

```typescript
// app/new-page/page.tsx
export default function NewPage() {
  return (
    <main className="min-h-screen bg-slate-950 py-12 px-4">
      <div className="max-w-7xl mx-auto">
        {/* Your content */}
      </div>
    </main>
  );
}
```

### إضافة مكون جديد

```typescript
// app/components/MyComponent.tsx
'use client';

export default function MyComponent() {
  return (
    <div className="radar-card">
      {/* Component content */}
    </div>
  );
}
```

## 🔌 التكامل مع API

### جلب البيانات

```typescript
import { getTransaction } from '@/lib/api';

const tx = await getTransaction('txid...');
console.log(tx);
```

### API Functions المتاحة

```typescript
// Transactions
getTransaction(txid)
getTransactionMerkleproof(txid)
getTransactionOutspends(txid)

// Addresses
getAddress(address)
getAddressTransactions(address, page)
getAddressMempoolTransactions(address)
getAddressUtxo(address)

// Blocks
getBlock(hashOrHeight)
getBlockTransactions(hash, page)
getLatestBlocks()

// Mempool
getMempoolStats()
getMempoolTransactions()
getMempoolRecent()

// Network
getNetworkStats()
getBitcoinPrice()
getRecommendedFees()
```

## 💾 State Management

### استخدام Zustand Store

```typescript
import { useSearchStore } from '@/store/searchStore';

export default function Component() {
  const { searchState, setQuery, setLoading } = useSearchStore();

  return (
    <input
      value={searchState.query}
      onChange={(e) => setQuery(e.target.value)}
    />
  );
}
```

## 📊 Utility Functions

```typescript
import {
  formatBTC,
  formatUSD,
  formatNumber,
  truncateAddress,
  truncateHash,
  isValidBitcoinAddress,
  isValidTransactionId,
  getAddressType,
  detectSearchType,
  copyToClipboard,
  getTimeAgo,
} from '@/lib/utils';
```

## 🎯 Features Development

### إضافة ميزة جديدة

1. **Create types** (`app/types/index.ts`)
2. **Create API functions** (`app/lib/api.ts`)
3. **Create store** (`app/store/*.ts`)
4. **Create components** (`app/components/*.tsx`)
5. **Create page** (`app/[page]/page.tsx`)

### مثال: إضافة Whale Alerts

```typescript
// 1. Add type
interface WhaleAlert {
  txid: string;
  from: string;
  to: string;
  value: number;
  timestamp: number;
}

// 2. Add API function
export async function getWhaleAlerts(): Promise<WhaleAlert[]> {
  // Implementation
}

// 3. Create page
// app/whale-alerts/page.tsx
export default function WhaleAlertsPage() {
  // Implementation
}
```

## 🧪 Testing

### Run Tests
```bash
npm test
```

### Type Checking
```bash
npm run type-check
```

### Build Check
```bash
npm run build
```

## 📈 Performance Tips

1. **Lazy Load Components**
   ```typescript
   import dynamic from 'next/dynamic';
   const HeavyComponent = dynamic(() => import('./HeavyComponent'), {
     loading: () => <p>Loading...</p>
   });
   ```

2. **Use useMemo for Expensive Calculations**
   ```typescript
   const memoizedValue = useMemo(() => {
     return expensiveCalculation(a, b);
   }, [a, b]);
   ```

3. **Optimize Images**
   ```typescript
   import Image from 'next/image';
   <Image src="/image.png" alt="desc" width={800} height={600} />
   ```

## 🐛 Debugging

### Browser DevTools
- Open DevTools (F12)
- Check Console for errors
- Use Network tab to monitor API calls
- Use React DevTools extension

### Server Logs
```bash
# Check Next.js logs
npm run dev 2>&1 | tee logs.txt

# Check build errors
npm run build
```

## 📚 Documentation

- [Next.js Documentation](https://nextjs.org/docs)
- [TypeScript Documentation](https://www.typescriptlang.org/docs/)
- [Tailwind CSS](https://tailwindcss.com/docs)
- [Zustand Documentation](https://github.com/pmndrs/zustand)
- [Mempool.space API](https://mempool.space/api)

## 🌐 Deployment

### Deploy to Vercel

```bash
# Install Vercel CLI
npm install -g vercel

# Deploy
vercel
```

### Deploy to Other Platforms

See [DEPLOYMENT.md](./DEPLOYMENT.md)

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## 🆘 Troubleshooting

### Port 3000 is already in use
```bash
# macOS/Linux
lsof -i :3000
kill -9 <PID>

# Windows
netstat -ano | findstr :3000
taskkill /PID <PID> /F
```

### Dependency Issues
```bash
# Clear node_modules and reinstall
rm -rf node_modules package-lock.json
npm install
```

### Build Fails
```bash
# Clear Next.js cache
rm -rf .next
npm run build
```

## 📞 Support

- Create an issue on GitHub
- Email: hello@transactionradar.com
- Twitter: @transactionradar

## 📄 License

MIT License - see LICENSE file

---

**Now you're ready to start building! 🎉**

Happy coding! 🚀
